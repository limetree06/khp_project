//IMPORTANT: use WebSocketProvider instead of HTTPProvider to be able to manage smart contract events
//const web3socket = new Web3('ws://localhost:8546');
//web3socket.setProvider(new Web3.providers.WebsocketProvider('ws://127.0.0.1:8546'));

var STATE;
var NUM;
web3socket = new Web3(new Web3.providers.WebsocketProvider("ws://127.0.0.1:7545"));
web3socket.eth.getAccounts(function(err, accounts) {
   if (err != null) {
     alert("Error retrieving accounts.");
     return;}

   if(accounts.length == 0) {
      alert("No account found! Make sure the Ethereum client is configured properly.");
     return;}

    account = accounts[0];
    console.log('Deafult Account: ' + account);
    web3socket.eth.defaultAccount = account;
   });

  web3socket.eth.getAccounts()
  .then(console.log); 
  var ABI = JSON.parse('[	{		"constant":false,		"inputs":[			{				"name":"_number",				"type":"uint256"			},			{				"name":"_sensorId",				"type":"string"			},			{				"name":"_sensorRadioactiveWasteType",				"type":"string"			}		],		"name":"registerSensor",		"outputs":[],		"payable":false,		"stateMutability":"nonpayable",		"type":"function"	},	{		"constant":true,		"inputs":[			{				"name":"_number",				"type":"uint256"			}		],		"name":"statusChecker",		"outputs":[			{				"name":"",				"type":"string"			}		],		"payable":false,		"stateMutability":"view",		"type":"function"	},	{		"constant":false,		"inputs":[],		"name":"kill",		"outputs":[],		"payable":false,		"stateMutability":"nonpayable",		"type":"function"	},	{		"constant":true,		"inputs":[			{				"name":"_number",				"type":"uint256"			}		],		"name":"getIdToDrum",		"outputs":[			{				"name":"",				"type":"string"			},			{				"name":"",				"type":"string"			},			{				"name":"",				"type":"string"			},			{				"name":"",				"type":"string"			},			{				"name":"",				"type":"uint256"			},			{				"name":"",				"type":"uint256[]"			},			{				"name":"",				"type":"uint256"			}		],		"payable":false,		"stateMutability":"view",		"type":"function"	},	{		"constant":false,		"inputs":[			{				"name":"_number",				"type":"uint256"			},			{				"name":"_temperature",				"type":"uint256"			}		],		"name":"storageDrum",		"outputs":[			{				"name":"",				"type":"uint256"			}		],		"payable":false,		"stateMutability":"nonpayable",		"type":"function"	},	{		"constant":false,		"inputs":[			{				"name":"_number",				"type":"uint256"			}		],		"name":"inspectDrum",		"outputs":[			{				"name":"",				"type":"uint256"			}		],		"payable":false,		"stateMutability":"nonpayable",		"type":"function"	},	{		"constant":false,		"inputs":[			{				"name":"_number",				"type":"uint256"			},			{				"name":"_drumId",				"type":"string"			},			{				"name":"_drumRadioactiveWasteType",				"type":"string"			},			{				"name":"_temperatureLimit",				"type":"uint256"			}		],		"name":"registerDrum",		"outputs":[],		"payable":false,		"stateMutability":"nonpayable",		"type":"function"	},	{		"inputs":[],		"payable":false,		"stateMutability":"nonpayable",		"type":"constructor"	},	{		"anonymous":false,		"inputs":[			{				"indexed":false,				"name":"",				"type":"uint256"			}		],		"name":"EverythingOk",		"type":"event"	},	{		"anonymous":false,		"inputs":[			{				"indexed":false,				"name":"",				"type":"uint256"			}		],		"name":"Suspicious",		"type":"event"	},	{		"anonymous":false,		"inputs":[			{				"indexed":false,				"name":"",				"type":"uint256"			}		],		"name":"Emergency",		"type":"event"	}]');
  var contractAddress = '0x17244e1E7dB8837Ef8e8402B47731A79De5A5d13'; 

  Contract =new web3socket.eth.Contract(ABI,contractAddress);

  //이벤드 잡아주는 함수
  //emit catch 하여 PrintAlarm 함수를 이용해서 화면 및 콘솔창 출력
  Contract.events.EverythingOk((err, events)=>{ 
    if (STATE == "Storage"){
      document.getElementById('sto_event').innerHTML = "EverythingOk";}

    else{
      document.getElementById('ins_event').innerHTML = "EverythingOk";}

    setTimeout(() => PrintnAlarm(events,"EverythingOk"), 5000);
    
  });

  Contract.events.Suspicious((err, events)=>{
    PrintnAlarm(events,"Suspicious");
  });
     
  Contract.events.Emergency((err, events)=>{
    if (STATE == "Storage"){
      document.getElementById('sto_event').innerHTML = "Emergency";}

    else{
      document.getElementById('ins_event').innerHTML = "Emergency";}
    setTimeout(() => PrintnAlarm(events,"Emergency"), 5000);
    
  });

function PrintnAlarm(events, theevent){
  //getIdToDrum 함수 from 솔리디티 호출

  if (STATE == "Storage"){console.log("Temperature : " + events.returnValues[0]);}

  Contract.methods.getIdToDrum(NUM).call().then(function(drum_info){
  if(STATE == "Inspection" & theevent != "EverythingOk"){
    alert("Emergency : The types do not match. Please check Alarm section");
    document.getElementById('Which_Process').innerHTML = theevent + " in inspection part  -  The types do not match"; 
    document.getElementById('getdrum_info').innerHTML =
      "Drum Id : " + drum_info[0] + 
      "/    Drum Waste Type : " + drum_info[1] ;
      document.getElementById('detail').innerHTML =
      "Sensor Id : " + drum_info[2] + 
      "/    Sensor Waste Type : " + drum_info[3];
  }
  
  else if (STATE == "Storage" & theevent != "EverythingOk"){
    console.log("Temperature : " + events.returnValues[0]);
    console.log("EROOR - Limit Temperature : " + drum_info[4])
    alert("Emergency : Limit temperature exceeded. Please check Alarm section");
    document.getElementById('Which_Process').innerHTML = theevent + " in storage part  -  Limit temperature exceeded.";  
    document.getElementById('getdrum_info').innerHTML = 
      "Drum Id : " + drum_info[0] +
      "/     Temperature Limit : " + drum_info[4];
      document.getElementById('detail').innerHTML = drum_info[5][0]+', '+drum_info[5][1]+', '+drum_info[5][2]+', '+drum_info[5][3]+', '+drum_info[5][4]+', '+drum_info[5][5]+', '+drum_info[5][6]+', '+drum_info[5][7]+', '+drum_info[5][8]+', '+drum_info[5][9];
  }

  });
};

  //버튼 클릭하면 필요한 함수 호출
  //#button_drum은 html 파일에서 지정한 각 버튼의 ID, 특정 아이디의 버튼이 동작하면 솔리디티파일 안에 있는 함수를 호출한다.
  //$("#drumNum").val() 은 #drumNum의 아이디를 가진 인풋값을 밸류
  $("#button_drum").click(function() {
    Contract.methods.registerDrum($("#drumNum").val(),$("#drumId").val(),$("#drumType").val(),  $("#temp").val()).send({from: web3socket.eth.defaultAccount, gas:3000000})
    .on('transactionHash', function(hash){
      document.getElementById('Transaction_Drum').innerHTML = "Transaction Hash : " + hash;
});
      });

    $("#button_sen").click(function() {
        Contract.methods.registerSensor($("#drumNumsen").val(),$("#sensorId").val(), $("#sensorType").val()).send({from: web3socket.eth.defaultAccount, gas:3000000})
        .on('transactionHash', function(hash1){
        document.getElementById('Transaction_sen').innerHTML = "Transaction Hash : " + hash1;
    });
});

    $("#button_check").click(function() {
      NUM = $("#getnum_SC").val();
      Contract.methods.statusChecker(NUM).call().then(function(Status) {
        document.getElementById('Status_check').innerHTML = Status;});

      Contract.methods.getIdToDrum($("#getnum_SC").val()).call().then(function(drum_info){
        document.getElementById('Status_detail').innerHTML = "Drum Number : " + $("#getnum_SC").val();
        document.getElementById('Status_Process').innerHTML = "Drum Id : " + drum_info[0] + 
        "/    Drum Waste Type : " + drum_info[1] ;
        document.getElementById('Status_condition').innerHTML = "Sensor Id : " + drum_info[2] + 
        "/    Sensor Waste Type : " + drum_info[3];
        document.getElementById('Status_info').innerHTML = "Temperature Limit : " + drum_info[4];   
      });
    });
    
      $("#button_ins").click(function() {
        NUM = $("#getins").val();
        STATE = "Inspection";
        Contract.methods.inspectDrum(NUM).send({from: web3socket.eth.defaultAccount, gas:3000000});      
      });

      $("#button_sto").click(function() {
        NUM = $("#getins").val();
        STATE = "Storage";
        Contract.methods.storageDrum(NUM,$("#temp_sto").val()).send({from: web3socket.eth.defaultAccount, gas:3000000});
  });

  //getdata버튼을 이용해서 csv에서 함수를 연속적으로 받아들인다
  //just 데모 시연을 위한 부분 - 이후에는 필요하지 않아보임
  $("#get_data").click(async function() {
    let promise = d3.csv("./data/data.csv");
    const routes = await promise;
    var i=0;
    if(routes[0].num1){
      while(i!=routes.length){
        STATE = "Storage";
        blindclick(NUM, routes[i].num1);
        i++;
      }
}
});

  function blindclick(num, temp){
    Contract.methods.storageDrum(num,temp).send({from: web3socket.eth.defaultAccount, gas:3000000});//데모를 위한 시간 지연  
 }